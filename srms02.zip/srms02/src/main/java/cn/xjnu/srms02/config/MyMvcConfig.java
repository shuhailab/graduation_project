package cn.xjnu.srms02.config;

import cn.xjnu.srms02.component.LoginHandlerInterceptor;
import cn.xjnu.srms02.component.MyLocaleResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyMvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/srms").setViewName("success");
    }

    @Bean
    public WebMvcConfigurer webMvcConfigurerAdapter(){
        WebMvcConfigurer web = new WebMvcConfigurer() {

            @Override
            public void addViewControllers(ViewControllerRegistry registry) {
                registry.addViewController("/").setViewName("login");
                registry.addViewController("/login.html").setViewName("login");
                registry.addViewController("/testforlogin.html").setViewName("test");
                registry.addViewController("/teacherhome.html").setViewName("teacher/teacherHome");
                registry.addViewController("/secretaryhome.html").setViewName("secretary/secretary-home");
                registry.addViewController("/managerhome.html").setViewName("manager/manager-home");
                registry.addViewController("/shuhai/project").setViewName("success");
                registry.addViewController("/user/login").setViewName("login");
                registry.addViewController("/register").setViewName("register");
                registry.addViewController("/user/bar").setViewName("commons/bar");
            }

            /**
             * 注册拦截器
             * @param registry
            */
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                System.out.println("请求被拦截");
                registry.addInterceptor(new LoginHandlerInterceptor()).addPathPatterns("/**")
                        .excludePathPatterns("/login.html","/","/user/login","/webjars/**","/asserts/**","/register","/usersubmit");
            }
        };
        return web;
    }


    @Bean
    public LocaleResolver localeResolver(){
        return new MyLocaleResolver();
    }

}
