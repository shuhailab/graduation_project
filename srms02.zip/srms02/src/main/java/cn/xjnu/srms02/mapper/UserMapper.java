package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Manager;
import cn.xjnu.srms02.bean.Secretary;
import cn.xjnu.srms02.bean.Teacher;
import cn.xjnu.srms02.bean.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.PathVariable;

@Mapper
public interface UserMapper {

    @Select("select * from user where id = #{id}")
    public User getUser(Integer id);

    public int insertTeacher(Teacher teacher);

    public int insertSecretary(Teacher teacher);

    public int insertManager(Teacher teacher);


}
