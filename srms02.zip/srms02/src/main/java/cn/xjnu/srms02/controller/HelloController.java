package cn.xjnu.srms02.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@Controller
public class HelloController {

    @ResponseBody
    @RequestMapping("/hello")
    public String hello(){
        return "Hello SpringBoot";
    }


    @RequestMapping("/hi")
    public String hi(Map<String,Object> map){
        map.put("hello","你好");
        map.put("userid","201652056");
        //return "teacher/testforteacher";
        return "teacher/testforteacher";
    }
}
