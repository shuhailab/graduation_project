package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.CrosswiseTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface CrosswiseTaskMapper {

    public List<CrosswiseTask> getCrosswiseTask(String tid);

    public List<CrosswiseTask> getUnfinishedCrosswiseTask(String tid);

    public String getAuthorId(int id);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertCrosswiseTask(CrosswiseTask crosswiseTask);

    public int updateCrosswiseTask(int id);

    public int insert_CrosswiseTask(CrosswiseTask crosswiseTask);

    public int insert_CollegeTask(CrosswiseTask crosswiseTask);
}
