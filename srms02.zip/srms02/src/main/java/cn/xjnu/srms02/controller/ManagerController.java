package cn.xjnu.srms02.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ManagerController {

    /**
     * 用户管理主页
     * @param tid
     * @return
     */
    @RequestMapping("/manager/users/{tid}")
    public String request_users(@PathVariable("tid")String tid){
        return "manager/manager-home";
    }

    /**
     * 科研人员管理
     * @param tid
     * @return
     */
    @RequestMapping("/sr/users/{tid}")
    public String request_sr_users(@PathVariable("tid")String tid){
        return "manager/manager-sr-users";
    }

    /**
     * 科研秘书管理界面
     * @param tid
     * @return
     */
    @RequestMapping("/secretaries/users/{tid}")
    public String request_sr_secretaries(@PathVariable("tid")String tid){
        return "manager/manager-sr-secretaries";
    }

    /**
     * 获取已结题科研项目页面
     * @param tid
     * @return
     */
    @RequestMapping("/projects/finished/{tid}")
    public String request_finished_project(@PathVariable("tid")String tid){
        return "manager/manager-finished-projects";
    }

    /**
     * 获取未结题科研项目页面
     * @param tid
     * @return
     */
    @RequestMapping("/projects/unfinished/{tid}")
    public String request_unfinished_project(@PathVariable("tid")String tid){
        return "manager/manager-unfinished-projects";
    }

    /**
     * 获取科研标兵页面
     * @param tid
     * @return
     */
    @RequestMapping("/sr/successors/{tid}")
    public String request_sr_successors(@PathVariable("tid")String tid){
        return "manager/manager-sr-successors";
    }

    @RequestMapping("/sr/status/{tid}")
    public String request_sr_status(@PathVariable("tid")String tid){
        return "manager/manager-sr-status";
    }

}
