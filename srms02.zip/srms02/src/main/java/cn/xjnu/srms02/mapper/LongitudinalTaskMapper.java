package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Award;
import cn.xjnu.srms02.bean.LongitudinalTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface LongitudinalTaskMapper {

    /**
     * 查询已结题项目
     * @param tid
     * @return
     */
    public List<LongitudinalTask> getLongitudinalTaskById(String tid);



    /**
     * 查询尚未结题项目
     * @param tid
     * @return
     */
    public List<LongitudinalTask> getUnfinishedLongitudinalTaskById(String tid);

    public String getAuthorId(int id);


    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertLongitudinalTask(LongitudinalTask longitudinalTask);

    public int insert_LongitudinalTask(LongitudinalTask longitudinalTask);

    public int updateLongitudinalTask(int id);
}
