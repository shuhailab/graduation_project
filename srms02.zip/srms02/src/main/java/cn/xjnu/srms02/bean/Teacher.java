package cn.xjnu.srms02.bean;

public class Teacher implements Person{
    private int id;//用户ID
    private String teacher_id;//职工号
    private String pwd;//密码
    private String teacher_name;//姓名
    private int gender;//性别
    private String mail;//邮箱
    private String phone;//联系电话
    private String education;//学历
    private String title;//职称
    private String research_direction;//研究方向
    private Integer school;//所属学院
    private String office_address;//办公地址
    private Integer typeof;//用户身份 0科研人员 1学院科研秘书 2科研处管理人员

    @Override
    public String toString() {
        return "Teacher{" +
                "id=" + id +
                ", teacher_id='" + teacher_id + '\'' +
                ", pwd='" + pwd + '\'' +
                ", teacher_name='" + teacher_name + '\'' +
                ", gender=" + gender +
                ", mail='" + mail + '\'' +
                ", phone='" + phone + '\'' +
                ", education='" + education + '\'' +
                ", title='" + title + '\'' +
                ", research_direction='" + research_direction + '\'' +
                ", school='" + school + '\'' +
                ", office_address='" + office_address + '\'' +
                ", typeof=" + typeof +
                '}';
    }

    public Integer getTypeof() {
        return typeof;
    }

    public void setTypeof(Integer typeof) {
        this.typeof = typeof;
    }

    @Override
    public String getName() {
        return this.teacher_name;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(String teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getResearch_direction() {
        return research_direction;
    }

    public void setResearch_direction(String research_direction) {
        this.research_direction = research_direction;
    }

    public Integer getSchool() {
        return school;
    }

    public void setSchool(Integer school) {
        this.school = school;
    }

    public String getOffice_address() {
        return office_address;
    }

    public void setOffice_address(String office_address) {
        this.office_address = office_address;
    }
}
