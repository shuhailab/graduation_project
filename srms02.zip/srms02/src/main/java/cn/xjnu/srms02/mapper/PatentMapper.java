package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Paper;
import cn.xjnu.srms02.bean.Patent;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Mapper
public interface PatentMapper {

    @Select("select * from patent where author_id = #{tid}")
    public List<Patent> getPatent(@PathVariable("tid") String tid);
}
