package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Work;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface WorkMapper02 {
    public List<Work> getWorkById(String tid);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertWork(Work work);

    public int insertAWork(Work work);
}
