package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Award;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface AwardMapper {

    public List<Award> getAwardById(String tid);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertAward(Award award);

    public int deleteAward(Integer id);

    public int insertAAward(Award award);
}
