package cn.xjnu.srms02.controller;

import cn.xjnu.srms02.bean.*;
import cn.xjnu.srms02.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Collection;

@Controller
public class TeacherController {

//    @Autowired
//    PaperMapper paperMapper01;

    @Autowired
    PaperMapper02 paperMapper;

    @Autowired
    WorkMapper workMapper;

    @Autowired
    WorkMapper02 workMapper02;

    @Autowired
    PatentMapper patentMapper;

    @Autowired
    PatentMapper02 patentMapper02;

    @Autowired
    AwardMapper awardMapper;

    @Autowired
    LongitudinalTaskMapper longitudinalTaskMapper;

    @Autowired
    CrosswiseTaskMapper crosswiseTaskMapper;
    /**
     * 获取当前登录用户发表的所有论文
     * @param model
     * @param tid
     * @return
     */
    @GetMapping("/papers/{tid}")
    public String getPapers(Model model, @PathVariable("tid") String tid){
        Collection<Paper> papers = paperMapper.getPaperById(tid);
        model.addAttribute("papers",papers);
        return "teacher/teacher-papers";
    }

    /**
     * 获取当前登录发表的所有论著
     * @param model
     * @param tid
     * @return
     */
    @GetMapping("/works/{tid}")
    public String getWorks(Model model, @PathVariable("tid") String tid){
        Collection<Work> works = workMapper02.getWorkById(tid);
        model.addAttribute("works",works);
        return "teacher/teacher-works";
    }

    /**
     * 获取当前登录用户的所有专利
     * @param model
     * @param tid
     * @return
     */
    @GetMapping("/patents/{tid}")
    public String getPatents(Model model,@PathVariable("tid") String tid){
        Collection<Patent> patents = patentMapper02.getPatentById(tid);
        model.addAttribute("patents",patents);
        return "teacher/teacher-patents";
    }


    /**
     * 获取当前登录用户的所有科研奖励
     */
    @GetMapping("/awards/{tid}")
    public String getAwards(Model model,@PathVariable("tid") String tid){
        Collection<Award> awards = awardMapper.getAwardById(tid);
        model.addAttribute("awards",awards);
        return "teacher/teacher-awards";
    }

    /**
     * 来到提交论文页面
     * @return
     */
    @RequestMapping("/submit/paper/{tid}")
    public String submitPaper(@PathVariable("tid") String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/submit-paper";
    }

    /**
     * 论文添加
     * @param paper
     * @return
     */
    @PostMapping("/submit-paper")
    public String addPaper(Paper paper){
        paperMapper.insertPaper(paper);
        String tid = paper.getAuthor_id();
        return "redirect:/papers/"+tid;
    }

    /**
     * 论著添加
     * @param work
     * @return
     */
    @PostMapping("/submit-work")
    public String addWork(Work work){
        workMapper02.insertWork(work);
        String tid = work.getAuthor_id();
        return "redirect:/works/"+tid;
    }

    @RequestMapping("/submit/work/{tid}")
    public String submitWork(@PathVariable("tid") String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/submit-work";
    }

    /**
     * 来到跳转页面
     * @param tid
     * @param model
     * @return
     */
    @RequestMapping("/submit/patent/{tid}")
    public String submitPatent(@PathVariable("tid") String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/submit-patent";
    }

    /**
     * 专利添加之后跳转到我的专利
     * @param patent
     * @return
     */
    @PostMapping("/submit-patent")
    public String addPatent(Patent patent){
        patentMapper02.insertPatent(patent);
        String tid = patent.getAuthor_id();
        return "redirect:/patents/"+tid;
    }

    /**
     * 来到科研奖励页面
     * @param tid
     * @param model
     * @return
     */
    @RequestMapping("/submit/award/{tid}")
    public String submitAward(@PathVariable("tid") String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/submit-award";
    }

    /**
     * 科研奖励详情页
     * @param award
     * @return
     */
    @PostMapping("/submit-award")
    public String addAward(Award award){
        awardMapper.insertAward(award);
        String tid = award.getAuthor();
        return "redirect:/awards/"+tid;
    }

    //纵向课题申请
    @RequestMapping("/apply/longitudinal/{tid}")
    public String apply_longitudinal_subject(@PathVariable("tid")String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/apply-portrait-project";
    }

    //横向课题或者校级课题申请
    @PostMapping("/apply-longitudinal-subject")
    public String add_longitudinal_subject(LongitudinalTask longitudinalTask){
        longitudinalTaskMapper.insertLongitudinalTask(longitudinalTask);
        String tid = longitudinalTask.getMan_id();
        return "redirect:/tasks/"+tid;
    }

    /**
     * 跳转到横向申请页面
     * @param tid
     * @param model
     * @return
     */
    @RequestMapping("/apply/crosswise/{tid}")
    public String apply_transverse_subject(@PathVariable("tid")String tid,Model model){
        model.addAttribute("tid",tid);
        return "teacher/apply-transverse-project";
    }

    /**
     * 横向项目，校级课题填写完毕跳转到我的已结题项目详情页
     * @param crosswiseTask
     * @return
     */
    @PostMapping("/apply-crosswise-subject")
    public String add_crosswise_task(CrosswiseTask crosswiseTask){
        crosswiseTaskMapper.insertCrosswiseTask(crosswiseTask);
        String tid = crosswiseTask.getMan_id();
        return "redirect:/tasks/"+tid;
    }

    /**
     * 查询所有结题项目
     * @param tid
     * @return
     */
    @RequestMapping("/tasks/{tid}")
    public String finished_tasks(@PathVariable("tid") String tid,Model model){
        Collection<LongitudinalTask> tasks = longitudinalTaskMapper.getLongitudinalTaskById(tid);
        Collection<CrosswiseTask> tasks02 = crosswiseTaskMapper.getCrosswiseTask(tid);
        model.addAttribute("untasks",tasks);
        model.addAttribute("untasks02",tasks02);
        return "teacher/teacher-projects";
    }

    @RequestMapping("/journal/{tid}")
    public String my_journals(@PathVariable("tid") String tid){
        return "teacher/teacher-journals";
    }

    /**
     * 查询未结题的项目
     * @param tid
     * @return
     */
    @RequestMapping("/unfinished/tasks/{tid}")
    public String my_unfinished_tasks(@PathVariable("tid") String tid,Model model){
        Collection<LongitudinalTask> tasks = longitudinalTaskMapper.getUnfinishedLongitudinalTaskById(tid);
        Collection<CrosswiseTask> tasks02 = crosswiseTaskMapper.getUnfinishedCrosswiseTask(tid);
        model.addAttribute("untasks",tasks);
        model.addAttribute("untasks02",tasks02);
        return "teacher/teacher-unfinished";
    }

    /**
     * 纵向项目申请结题
     * @param id
     * @return
     */
    @RequestMapping("/apply-height-finished/{id}")
    public String apply_height_finished(@PathVariable("id") String id){
        int index = Integer.parseInt( id );
        longitudinalTaskMapper.updateLongitudinalTask(index);
        String tid = longitudinalTaskMapper.getAuthorId(index);
        return "redirect:/unfinished/tasks/"+tid;
    }


    /**
     * 横向项目 校级课题申请结题
     * @param id
     * @return
     */
    @RequestMapping("/apply-width-finished/{id}")
    public String apply_width_finished(@PathVariable("id") String id){
        int index = Integer.parseInt( id );
        crosswiseTaskMapper.updateCrosswiseTask(index);
        String tid = crosswiseTaskMapper.getAuthorId(index);
        return "redirect:/unfinished/tasks/"+tid;
    }




}
