package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Teacher;
import org.apache.ibatis.annotations.*;

@Mapper
public interface TeacherMapper {

    @Select("select * from teacher where teacher_id = #{tid}")
    public Teacher selectTeacherBytid(String tid);

    @Delete("delete from teacher where teacher_idi = #{tid}")
    public int deleteTechById(int tid);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    @Insert("insert into teacher(teacher_id,name) values(#{teacher_id},#{name})")
    public int insertTech(Teacher teacher);

    @Update("update teacher set name=#{teacher_name} where teacher_id=#{teacher_id}")
    public int updateTech(Teacher teacher);

    @Select("select * from teacher where teacher_id = #{tid} and typeof = 0")
    public Teacher check_teacher(String tid);

    @Select("select * from teacher where teacher_id = #{tid} and typeof = 1")
    public Teacher check_secretary(String tid);

    @Select("select * from teacher where teacher_id = ${tid} and typeof = 2")
    public Teacher check_manager(String tid);

    public int insertTeacher(Teacher teacher);

    public int insertATeacher(Teacher teacher);


}
