package cn.xjnu.srms02.bean;

public class Patent {
    private Integer id;
    private String patent_id;
    private String patent_name;
    private String authors;
    private String author_id;
    private String grant_date;
    private String description;
    private Integer status;
    private Integer school;

    @Override
    public String toString() {
        return "Patent{" +
                "id=" + id +
                ", patent_id='" + patent_id + '\'' +
                ", patent_name='" + patent_name + '\'' +
                ", authors='" + authors + '\'' +
                ", author_id='" + author_id + '\'' +
                ", grant_date='" + grant_date + '\'' +
                ", desc='" + description + '\'' +
                '}';
    }

    public Integer getSchool() {
        return school;
    }

    public void setSchool(Integer school) {
        this.school = school;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPatent_id() {
        return patent_id;
    }

    public void setPatent_id(String patent_id) {
        this.patent_id = patent_id;
    }

    public String getPatent_name() {
        return patent_name;
    }

    public void setPatent_name(String patent_name) {
        this.patent_name = patent_name;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(String author_id) {
        this.author_id = author_id;
    }

    public String getGrant_date() {
        return grant_date;
    }

    public void setGrant_date(String grant_date) {
        this.grant_date = grant_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
