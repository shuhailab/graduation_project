package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Manager;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.PathVariable;

@Mapper
public interface ManagerMapper {

    @Select("select * from manager where teacher_id = #{tid}")
    public Manager selectManagerBytid(@PathVariable("tid") String tid);
}
