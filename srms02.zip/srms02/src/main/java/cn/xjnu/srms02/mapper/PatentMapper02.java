package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Paper;
import cn.xjnu.srms02.bean.Patent;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface PatentMapper02 {
    public List<Patent> getPatentById(String tid);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertPatent(Patent patent);

    public int insertAPatent(Patent patent);
}
