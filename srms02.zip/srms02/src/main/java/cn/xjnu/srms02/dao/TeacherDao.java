package cn.xjnu.srms02.dao;

public class TeacherDao {
    
}
