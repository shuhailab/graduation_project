package cn.xjnu.srms02.bean;

public class CrosswiseTask {
    private Integer id;
    private String project_id;
    private String project_name;
    private String project_class;
    private String agency;
    private String manager;
    private String man_id;
    private String man_phone;
    private String man_mail;
    private String sign_date;
    private String start_date;
    private String end_date;
    private String user_name;
    private String user_address;
    private String user_manager;
    private String user_phone;
    private String user_mail;
    private String description;
    private String status;
    private Integer typeof;

    @Override
    public String toString() {
        return "CrosswiseTask{" +
                "id=" + id +
                ", project_name='" + project_name + '\'' +
                ", project_class='" + project_class + '\'' +
                ", agency='" + agency + '\'' +
                ", manager='" + manager + '\'' +
                ", man_id='" + man_id + '\'' +
                ", man_phone='" + man_phone + '\'' +
                ", man_mail='" + man_mail + '\'' +
                ", sign_date='" + sign_date + '\'' +
                ", start_date='" + start_date + '\'' +
                ", end_date='" + end_date + '\'' +
                ", user_name='" + user_name + '\'' +
                ", user_address='" + user_address + '\'' +
                ", user_manager='" + user_manager + '\'' +
                ", user_phone='" + user_phone + '\'' +
                ", user_mail='" + user_mail + '\'' +
                ", description='" + description + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

    public String getProject_id() {
        return project_id;
    }

    public void setProject_id(String project_id) {
        this.project_id = project_id;
    }

    public Integer getTypeof() {
        return typeof;
    }

    public void setTypeof(Integer typeof) {
        this.typeof = typeof;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public String getProject_class() {
        return project_class;
    }

    public void setProject_class(String project_class) {
        this.project_class = project_class;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getMan_id() {
        return man_id;
    }

    public void setMan_id(String man_id) {
        this.man_id = man_id;
    }

    public String getMan_phone() {
        return man_phone;
    }

    public void setMan_phone(String man_phone) {
        this.man_phone = man_phone;
    }

    public String getMan_mail() {
        return man_mail;
    }

    public void setMan_mail(String man_mail) {
        this.man_mail = man_mail;
    }

    public String getSign_date() {
        return sign_date;
    }

    public void setSign_date(String sign_date) {
        this.sign_date = sign_date;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_address() {
        return user_address;
    }

    public void setUser_address(String user_address) {
        this.user_address = user_address;
    }

    public String getUser_manager() {
        return user_manager;
    }

    public void setUser_manager(String user_manager) {
        this.user_manager = user_manager;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public String getUser_mail() {
        return user_mail;
    }

    public void setUser_mail(String user_mail) {
        this.user_mail = user_mail;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
