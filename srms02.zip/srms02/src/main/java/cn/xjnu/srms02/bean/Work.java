package cn.xjnu.srms02.bean;

public class Work {
    private Integer id;
    private String author;
    private String author_id;
    private String work_name;
    private String type;
    private String publish_year;
    private String address;
    private String press;
    private String ISBN;
    private Integer status;
    private Integer school;

    @Override
    public String toString() {
        return "Work{" +
                "id=" + id +
                ", author='" + author + '\'' +
                ", author_id='" + author_id + '\'' +
                ", work_name='" + work_name + '\'' +
                ", type='" + type + '\'' +
                ", publish_year='" + publish_year + '\'' +
                ", address='" + address + '\'' +
                ", press='" + press + '\'' +
                ", ISBN='" + ISBN + '\'' +
                '}';
    }

    public Integer getSchool() {
        return school;
    }

    public void setSchool(Integer school) {
        this.school = school;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(String author_id) {
        this.author_id = author_id;
    }

    public String getWork_name() {
        return work_name;
    }

    public void setWork_name(String work_name) {
        this.work_name = work_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPublish_year() {
        return publish_year;
    }

    public void setPublish_year(String publish_year) {
        this.publish_year = publish_year;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPress() {
        return press;
    }

    public void setPress(String press) {
        this.press = press;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
}
