package cn.xjnu.srms02.controller;

import cn.xjnu.srms02.bean.*;
import cn.xjnu.srms02.mapper.*;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.rmi.CORBA.UtilDelegate;
import java.util.List;

@Controller
public class SecretaryController {

    @Autowired
    SecretaryMapper secretaryMapper;

    @Autowired
    TeacherMapper teacherMapper;

    @Autowired
    AwardMapper awardMapper;

    @Autowired
    PaperMapper02 paperMapper02;

    @Autowired
    WorkMapper02 workMapper02;

    @Autowired
    PatentMapper02 patentMapper02;

    @Autowired
    LongitudinalTaskMapper longitudinalTaskMapper;

    @Autowired
    CrosswiseTaskMapper crosswiseTaskMapper;

    @RequestMapping("/secretaryhome/{tid}")
    public String secretary_home(@PathVariable("tid")String tid){
        return "secretary/secretary-home";
    }

    //本院科研人员
    @RequestMapping("/secretary/users/{tid}")
    public String get_users(@PathVariable("tid")String tid, Model model){
        System.out.println("tid = " + tid);
        Teacher teacher = secretaryMapper.select_secretary_school(tid);
        Integer school = teacher.getSchool();
        List<Teacher> list = secretaryMapper.select_school_users(school);
        model.addAttribute("teachers",list);
        model.addAttribute("tid",tid);
        return "secretary/secretary-users";
    }

    //某学院所有科研奖励
    @RequestMapping("/secretary/awards/{tid}")
    public String get_awards(@PathVariable("tid")String tid,Model model){
        Teacher teacher = secretaryMapper.select_secretary_school(tid);
        Integer school = teacher.getSchool();
        List<Award> list = secretaryMapper.select_school_awards(school);
        model.addAttribute("awards",list);
        model.addAttribute("tid",tid);
        return "secretary/secretary-result";
    }

    //横向项目管理
    @RequestMapping("/secretary/horizontal/{tid}")
    public String get_widths(@PathVariable("tid")String tid,Model model){
        Integer agency = secretaryMapper.select_school_of_secretary(tid);
        List<CrosswiseTask> unfinished_crosswise_task = secretaryMapper.select_unfinished_crosswise_task(agency);
        List<CrosswiseTask> unfinished_college_task = secretaryMapper.select_unfinished_college_task(agency);
        List<CrosswiseTask> finished_crosswise_task = secretaryMapper.select_finished_crosswise_task(agency);
        List<CrosswiseTask> finished_college_task = secretaryMapper.select_finished_college_task(agency);
        model.addAttribute("unfinished_crosswise_task",unfinished_crosswise_task);
        model.addAttribute("unfinished_college_task",unfinished_college_task);
        model.addAttribute("finished_crosswise_task",finished_crosswise_task);
        model.addAttribute("finished_college_task",finished_college_task);
        return "secretary/secretary-transverse";
    }



    //纵向项目管理
    @RequestMapping("/secretary/longitudinal/{tid}")
    public String get_heights(@PathVariable("tid")String tid,Model model){
        Integer proxy = secretaryMapper.select_school_of_secretary(tid);
        List<LongitudinalTask> list = secretaryMapper.select_unfinished_longitudinal_task(proxy);
        List<LongitudinalTask> list1 = secretaryMapper.select_finished_longitudinal_task(proxy);
        model.addAttribute("unlongtasks",list);
        model.addAttribute("longtasks",list1);
        model.addAttribute("tid",tid);
        return "secretary/secretary-portrait";
    }

    //论文审核
    @RequestMapping("/review/paper/{tid}")
    public String review_paper(@PathVariable("tid") String tid,Model model){
        Integer school = secretaryMapper.select_school_of_secretary(tid);
        List<Paper> list = secretaryMapper.selectReviewPaper(school);
        model.addAttribute("papers",list);
        model.addAttribute("tid",tid);
        return "secretary/secretary-review-paper";
    }

    //论著审核
    @RequestMapping("/review/work/{tid}")
    public String review_work(@PathVariable("tid")String tid,Model model){
        Integer school = secretaryMapper.select_school_of_secretary(tid);
        List<Work>  list = secretaryMapper.selectReviewWork(school);
        model.addAttribute("works",list);
        return "secretary/secretary-review-work";
    }

    //专利审核
    @RequestMapping("/review/patent/{tid}")
    public String review_patent(@PathVariable("tid")String tid,Model model){
        Integer school = secretaryMapper.select_school_of_secretary(tid);
        List<Patent> list = secretaryMapper.selectReviewPatent(school);
        model.addAttribute("patents",list);
        return "secretary/secretary-review-patent";
    }

    //科研奖励审核
    @RequestMapping("/review/award/{tid}")
    public String review_award(@PathVariable("tid")String tid,Model model){
        Integer school = secretaryMapper.select_school_of_secretary(tid);
        List<Award> list = secretaryMapper.selectReviewAward(school);
        model.addAttribute("awards",list);
        return "secretary/secretary-review-award";
    }


    //联系处长
    @RequestMapping("/call/manager/{tid}")
    public String call_manager(@PathVariable("tid")String tid){
        return "secretary/secretary-callmanager";
    }

    //科研日志
    @RequestMapping("/secretary/journals/{tid}")
    public String school_journal(@PathVariable("tid")String tid){
        return "secretary/secretary-journal";
    }

    //发送广播通知
    @RequestMapping("/edit/notice/{tid}")
    public String edit_notice(@PathVariable("tid")String tid){
        return "secretary/secretary-info";
    }

    //发送单播通知
    @RequestMapping("/send/info/{tid}")
    public String edit_one_notice(@PathVariable("tid")String tid){
        return "secretary/secretary-info-one";
    }


    //教师删除
    @DeleteMapping("/teacher/{tid}/{id}")
    public String deleteTeacher(@PathVariable("id")Integer id,@PathVariable("tid") String tid){
        //删除操作
        secretaryMapper.delete_teacher(id);
        return "redirect:/secretary/users/"+tid;
    }

    //编辑用户信息
    @GetMapping("/edit/{tid}/{id}")
    public String editTeacher(@PathVariable("tid")String tid, @PathVariable("id")Integer id,Model model){
       // return "redirect:/secretary/users/"+tid;
        Teacher teacher = secretaryMapper.selectTeacherById(id);
        model.addAttribute("teacher",teacher);
        model.addAttribute("tid",tid);
        return "secretary/edit-teacher";
    }

    //编辑科研奖励信息
    @GetMapping("/edit_award/{tid}/{id}")
    public String editAward(@PathVariable("tid")String tid,@PathVariable("id")Integer id,Model model){
        Award award = secretaryMapper.selectAwardById(id);
        model.addAttribute("award",award);
        model.addAttribute("tid",tid);
        return "secretary/edit-award";
    }

    //删除科研奖励信息
    @DeleteMapping("/award/{tid}/{id}")
    public String deleteAward(@PathVariable("id")Integer id,@PathVariable("tid")String tid){
        secretaryMapper.delete_award(id);
        return "redirect:/secretary/awards/"+tid;
    }

    //提交用户信息更改
    @PutMapping("/usersubmit/{tid}")
    public String submitUserUpdate(@PathVariable("tid")String tid,Teacher teacher){
        Integer id = teacher.getId();
        secretaryMapper.delete_teacher(id);
        teacherMapper.insertATeacher(teacher);
        return "redirect:/secretary/users/"+tid;
    }

    //提交科研奖励信息更改
    @PutMapping("/awardsubmit/{tid}")
    public String submitAwardUpdate(@PathVariable("tid")String tid,Award award){
        Integer id = award.getId();
        secretaryMapper.delete_award(id);
        awardMapper.insertAAward(award);
        return "redirect:/secretary/awards/"+tid;
    }


    //审核与否决
    //_______________________________________________________________________________________________________________________________________________

    //论文审核通过
    @PutMapping("/review/paper/pass/{tid}/{pid}")
    public String reviewPaperPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,Paper paper){
        System.out.println(paper);
        secretaryMapper.delete_paper(pid);
        paperMapper02.insertAPaper(paper);
        return "redirect:/review/paper/"+tid;
    }

    //论文审核不通过
    @RequestMapping("/review/paper/fail/{tid}/{id}")
    public String reviewPaperFailed(@PathVariable("tid")String tid,@PathVariable("id")Integer id){
        secretaryMapper.update_review_paper(id);
        return "redirect:/review/paper/"+tid;
    }


    //论著审核通过
    @PutMapping("/review/work/pass/{tid}/{pid}")
    public String reviewWorkPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,Work work){
        secretaryMapper.delete_work(pid);
        workMapper02.insertAWork(work);
        return "redirect:/review/work/"+tid;
    }

    //论著审核不通过
    @RequestMapping("/review/work/fail/{tid}/{id}")
    public String reviewWorkFailed(@PathVariable("tid")String tid,@PathVariable("id")Integer id){
        secretaryMapper.update_review_work(id);
        return "redirect:/review/work/"+tid;
    }

    //专利审核通过
    @PutMapping("/review/patent/pass/{tid}/{pid}")
    public String reviewPatentPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,Patent patent){
        secretaryMapper.delete_patent(pid);
        patentMapper02.insertAPatent(patent);
        return "redirect:/review/patent/"+tid;
    }

    //专利审核不通过
    @RequestMapping("/review/patent/fail/{tid}/{pid}")
    public String reviewPatentFailed(@PathVariable("tid")String tid,@PathVariable("pid")Integer id){
        secretaryMapper.update_review_patent(id);
        return "redirect:/review/patent/"+tid;
    }

    //科研奖励审核通过
    @PutMapping("/review/award/pass/{tid}/{pid}")
    public String reviewAwardPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,Award award){
        secretaryMapper.delete_award(pid);
        awardMapper.insertAAward(award);
        return "redirect:/review/award/"+tid;
    }

    //科研奖励审核不通过
    @RequestMapping("/review/award/fail/{tid}/{pid}")
    public String reviewAwardFailed(@PathVariable("tid")String tid,@PathVariable("pid")Integer id){
        secretaryMapper.update_review_award(id);
        return "redirect:/review/award/"+tid;
    }
    //------------------------------------------------------------------------------------------------------------------------------------------------

    //-----------------------------项目管理-----------------------------------------------------------------------------------
    //纵向项目审核通过
    @PutMapping("/review/unlongtask/pass/{tid}/{pid}")
    public String reviewUnLongTaskPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,LongitudinalTask longitudinalTask){
        secretaryMapper.delete_long_task(pid);
        longitudinalTaskMapper.insert_LongitudinalTask(longitudinalTask);
        return "redirect:/secretary/longitudinal/"+tid;
    }

    //纵向项目审核不通过
    @RequestMapping("/review/unlongtask/fail/{tid}/{pid}")
    public String reviewUnLongTaskFailed(@PathVariable("tid")String tid,@PathVariable("pid")Integer id){
        secretaryMapper.update_unfinished_task(id);
        return "redirect:/secretary/longitudinal/"+tid;
    }

    //横向项目审核通过
    @PutMapping("/review/unwidthtask/pass/{tid}/{pid}")
    public String reviewWidthTaskPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,CrosswiseTask crosswiseTask){
        secretaryMapper.delete_width_task(pid);
        crosswiseTaskMapper.insert_CrosswiseTask(crosswiseTask);
        return "redirect:/secretary/horizontal/"+tid;
    }

    //横向项目审核不通过
    @RequestMapping("/review/unwidthtask/fail/{tid}/{pid}")
    public String reviewWidthTaskFailed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid){
        secretaryMapper.update_unfinished_width_task(pid);
        return "redirect:/secretary/horizontal/"+tid;
    }

    //校内课题审核通过
    @PutMapping("/review/uncollegetask/pass/{tid}/{pid}")
    public String reviewCollegeTaskPassed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid,CrosswiseTask crosswiseTask){
        secretaryMapper.delete_width_task(pid);
        crosswiseTaskMapper.insert_CollegeTask(crosswiseTask);
        return "redirect:/secretary/horizontal/"+tid;
    }

    //校内课题审核不通过
    @RequestMapping("/review/uncollegetask/fail/{tid}/{pid}")
    public String reviewCollegeTaskFailed(@PathVariable("tid")String tid,@PathVariable("pid")Integer pid){
        secretaryMapper.update_unfinished_width_task(pid);
        return "redirect:/secretary/horizontal/"+tid;
    }

}
