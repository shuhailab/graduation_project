package cn.xjnu.srms02.bean;

public class Paper {
    private Integer id;
    private String title_cn;
    private String title_en;
    private String first_author;
    private String author_school;
    private String authors;
    private String keywords;
    private String publication_date;
    private String journal;
    private String journal_id;
    private String journal_rank;
    private String paper_class;
    private String doi;
    private String author_id;
    private String description;
    private Integer status;

    @Override
    public String toString() {
        return "Paper{" +
                "id=" + id +
                ", title_cn='" + title_cn + '\'' +
                ", title_en='" + title_en + '\'' +
                ", first_author='" + first_author + '\'' +
                ", author_school='" + author_school + '\'' +
                ", authors='" + authors + '\'' +
                ", keys='" + keywords + '\'' +
                ", publication_date='" + publication_date + '\'' +
                ", journal='" + journal + '\'' +
                ", journal_id='" + journal_id + '\'' +
                ", journal_rank='" + journal_rank + '\'' +
                ", paper_class='" + paper_class + '\'' +
                ", doi='" + doi + '\'' +
                ", author_id='" + author_id + '\'' +
                '}';
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle_cn() {
        return title_cn;
    }

    public void setTitle_cn(String title_cn) {
        this.title_cn = title_cn;
    }

    public String getTitle_en() {
        return title_en;
    }

    public void setTitle_en(String title_en) {
        this.title_en = title_en;
    }

    public String getFirst_author() {
        return first_author;
    }

    public void setFirst_author(String first_author) {
        this.first_author = first_author;
    }

    public String getAuthor_school() {
        return author_school;
    }

    public void setAuthor_school(String author_school) {
        this.author_school = author_school;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getPublication_date() {
        return publication_date;
    }

    public void setPublication_date(String publication_date) {
        this.publication_date = publication_date;
    }

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public String getJournal_id() {
        return journal_id;
    }

    public void setJournal_id(String journal_id) {
        this.journal_id = journal_id;
    }

    public String getJournal_rank() {
        return journal_rank;
    }

    public void setJournal_rank(String journal_rank) {
        this.journal_rank = journal_rank;
    }

    public String getPaper_class() {
        return paper_class;
    }

    public void setPaper_class(String paper_class) {
        this.paper_class = paper_class;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(String author_id) {
        this.author_id = author_id;
    }
}
