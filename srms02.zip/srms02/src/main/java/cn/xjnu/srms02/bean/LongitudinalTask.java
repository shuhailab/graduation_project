package cn.xjnu.srms02.bean;

//纵向项目
public class LongitudinalTask {
    private Integer id;
    private String project_id;
    private String project_name;
    private String project_manager;
    private String man_id;
    private String man_phone;
    private String man_mail;
    private String participant;
    private Integer proxy;
    private String project_from;
    private String project_dept;
    private String project_rank;
    private String start_date;
    private String end_date;
    private String result;
    private String description;
    private Integer status;
    @Override
    public String toString() {
        return "LongitudinalTask{" +
                "id=" + id +
                ", project_id='" + project_id + '\'' +
                ", project_name='" + project_name + '\'' +
                ", project_manager='" + project_manager + '\'' +
                ", man_id='" + man_id + '\'' +
                ", man_phone='" + man_phone + '\'' +
                ", man_mail='" + man_mail + '\'' +
                ", participant='" + participant + '\'' +
                ", proxy='" + proxy + '\'' +
                ", project_from='" + project_from + '\'' +
                ", project_dept='" + project_dept + '\'' +
                ", project_rank='" + project_rank + '\'' +
                ", start_date='" + start_date + '\'' +
                ", end_date='" + end_date + '\'' +
                ", result='" + result + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProject_id() {
        return project_id;
    }

    public void setProject_id(String project_id) {
        this.project_id = project_id;
    }

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public String getProject_manager() {
        return project_manager;
    }

    public void setProject_manager(String project_manager) {
        this.project_manager = project_manager;
    }

    public String getMan_id() {
        return man_id;
    }

    public void setMan_id(String man_id) {
        this.man_id = man_id;
    }

    public String getMan_phone() {
        return man_phone;
    }

    public void setMan_phone(String man_phone) {
        this.man_phone = man_phone;
    }

    public String getMan_mail() {
        return man_mail;
    }

    public void setMan_mail(String man_mail) {
        this.man_mail = man_mail;
    }

    public String getParticipant() {
        return participant;
    }

    public void setParticipant(String participant) {
        this.participant = participant;
    }

    public Integer getProxy() {
        return proxy;
    }

    public void setProxy(Integer proxy) {
        this.proxy = proxy;
    }

    public String getProject_from() {
        return project_from;
    }

    public void setProject_from(String project_from) {
        this.project_from = project_from;
    }

    public String getProject_dept() {
        return project_dept;
    }

    public void setProject_dept(String project_dept) {
        this.project_dept = project_dept;
    }

    public String getProject_rank() {
        return project_rank;
    }

    public void setProject_rank(String project_rank) {
        this.project_rank = project_rank;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
