package cn.xjnu.srms02.bean;

public class Award {

    private Integer id;
    private String sr_name;
    private String project_class;
    private String project_rank;
    private String award_name;
    private String rank;
    private String author;
    private String authors;
    private String get_date;
    private String agency;
    private String description;
    private String status;

    @Override
    public String toString() {
        return "Award{" +
                "id=" + id +
                ", sr_name='" + sr_name + '\'' +
                ", project_class='" + project_class + '\'' +
                ", project_rank='" + project_rank + '\'' +
                ", award_name='" + award_name + '\'' +
                ", rank='" + rank + '\'' +
                ", author='" + author + '\'' +
                ", authors='" + authors + '\'' +
                ", get_date='" + get_date + '\'' +
                ", agency='" + agency + '\'' +
                ", description='" + description + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSr_name() {
        return sr_name;
    }

    public void setSr_name(String sr_name) {
        this.sr_name = sr_name;
    }

    public String getProject_class() {
        return project_class;
    }

    public void setProject_class(String project_class) {
        this.project_class = project_class;
    }

    public String getProject_rank() {
        return project_rank;
    }

    public void setProject_rank(String project_rank) {
        this.project_rank = project_rank;
    }

    public String getAward_name() {
        return award_name;
    }

    public void setAward_name(String award_name) {
        this.award_name = award_name;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getGet_date() {
        return get_date;
    }

    public void setGet_date(String get_date) {
        this.get_date = get_date;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
