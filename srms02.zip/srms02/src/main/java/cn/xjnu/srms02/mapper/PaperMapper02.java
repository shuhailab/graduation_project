package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Paper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import java.util.List;

@Mapper
public interface PaperMapper02 {
    public List<Paper> getPaperById(String tid);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    public void insertPaper(Paper paper);

    public int insertAPaper(Paper paper);
}

