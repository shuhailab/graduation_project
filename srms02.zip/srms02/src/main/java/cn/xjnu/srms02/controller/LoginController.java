package cn.xjnu.srms02.controller;

import cn.xjnu.srms02.bean.*;
import cn.xjnu.srms02.mapper.ManagerMapper;
import cn.xjnu.srms02.mapper.SecretaryMapper;
import cn.xjnu.srms02.mapper.TeacherMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpSession;
import javax.swing.*;
import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    TeacherMapper teacherMapper;

    @Autowired
    SecretaryMapper secretaryMapper;

    @Autowired
    ManagerMapper managerMapper;

    //登录模块判断逻辑
    @PostMapping(value = "/user/login")
    public String login(@RequestParam("user_id") String user_id,
                        @RequestParam("user_password") String user_pwd,
                        @RequestParam("user_type") String user_type,
                        Map<String,Object> map, HttpSession session){
        Person person = null;
        int type = 0;
        if("教师或研究员".equals(user_type)){
            person = teacherMapper.check_teacher(user_id);
            if(person != null)type = 1;
        }else if("科研秘书".equals(user_type)){
            person = teacherMapper.check_secretary(user_id);
            if(person != null)type = 2;
        }else{
            person = teacherMapper.check_manager(user_id);
            if(person != null)type = 3;
        }
        if(type != 0 && person.getPwd().equals(user_pwd)){
            session.setAttribute("loginUser",user_id);
            if(type == 1){
                return "redirect:/teacherhome.html";
            }else if(type == 2){
                return "redirect:/secretaryhome.html";
            }else{
                return "redirect:/managerhome.html";
            }
        }else{
            map.put("msg","该用户不存在");
            return "login";
        }
    }

    @RequestMapping("/thome")
    public String teacherforhome(Map<String,Object> map){
        map.put("userid","201652056");
        //return "teacher/teacherHome";
        return "redirect:/teacherhome.html";
    }

    @PostMapping("/usersubmit")
    public String addUser(Teacher teacher){
        int type = teacher.getTypeof();
        teacherMapper.insertTeacher(teacher);
        //System.out.println(teacher);
        return "redirect:/login.html";
    }
}
