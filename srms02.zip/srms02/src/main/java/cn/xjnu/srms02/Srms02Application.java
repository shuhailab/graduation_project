package cn.xjnu.srms02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Srms02Application {

    public static void main(String[] args) {

        SpringApplication.run(Srms02Application.class, args);
    }

}
