package cn.xjnu.srms02.bean;

public interface Person {

    public String getPwd();

    public String getName();
}
