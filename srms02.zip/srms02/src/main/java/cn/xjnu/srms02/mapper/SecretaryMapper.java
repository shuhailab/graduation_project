package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.*;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Mapper
public interface SecretaryMapper {

    @Select("select * from secretary where teacher_id = #{tid}")
    public Secretary selectSecretaryByTid(@PathVariable("tid") String tid);

    @Select("select * from teacher where id = #{id}")
    public Teacher selectTeacherById(Integer id);

    //查询科研奖励
    @Select("select * from sr_award where id = #{id}")
    public Award selectAwardById(Integer id);

    //查询某学院所有提交审核的论文
    @Select("select * from paper where author_school = #{school} and status = 2")
    public List<Paper> selectReviewPaper(Integer school);

    //查询某学院所有提交审核的论著
    @Select("select * from work where school = #{school} and status = 2")
    public List<Work> selectReviewWork(Integer school);

    //查询某学院所有提交审核的专利
    @Select("select * from patent where school = #{school} and status = 2")
    public List<Patent> selectReviewPatent(Integer school);

    //查询某学院所有提交审核的科研奖励
    @Select("select * from sr_award where agency = #{school} and status = 2")
    public List<Award> selectReviewAward(Integer school);

    @Select("select * from teacher where teacher_id = #{tid} and typeof = 1")
    public Teacher select_secretary_school(String tid);

    @Select("select * from teacher where school = #{school} and typeof = 0")
    public List<Teacher> select_school_users(Integer school);

    //获取某个学院所有的科技奖励
    @Select("select * from sr_award where agency = #{school}")
    public List<Award> select_school_awards(Integer school);

    //删除教师
    @Delete("delete from teacher where id = #{id}")
    public int delete_teacher(Integer id);

    //删除科研奖励
    @Delete("delete from sr_award where id = #{id}")
    public int delete_award(Integer id);

    //删除一篇论文
    @Delete("delete from paper where id = #{id}")
    public int delete_paper(Integer id);

    //删除一部论著
    @Delete("delete from work where id = #{id}")
    public int delete_work(Integer id);

    //删除一个专利
    @Delete("delete from patent where id = #{id}")
    public int delete_patent(Integer id);



    //查询某教学秘书所在学院
    @Select("select school from teacher where teacher_id = #{tid}")
    public Integer select_school_of_secretary(String tid);

    //更改论文审核状态
    @Update("update paper set status = 3 where id = #{id}")
    public int update_review_paper(Integer id);

    //更改论著审核状态
    @Update("update work set status = 3 where id = #{id}")
    public int update_review_work(Integer id);

    //更改专利审核状态
    @Update("update patent set status = 3 where id = #{id}")
    public int update_review_patent(Integer id);

    //更改科研奖励审核状态
    @Update("update sr_award set status = 3 where id = #{id}")
    public int update_review_award(Integer id);


    //****************************************项目管理*******************************************************************************************
    //查询某学院纵向项目申请结题
    @Select("select * from apply_portrait_project where proxy = #{proxy} and status = 2")
    public List<LongitudinalTask> select_unfinished_longitudinal_task(Integer proxy);

    //查询某学院纵向项目申请结题记录
    @Select("select * from apply_portrait_project where proxy = #{proxy} and status = 1")
    public List<LongitudinalTask> select_finished_longitudinal_task(Integer proxy);

    //更改纵向项目申请结题的审核状态
    @Update("update apply_portrait_project set status = 3 where id = #{id}")
    public int update_unfinished_task(Integer id);

    //删除一个纵向项目
    @Delete("delete from apply_portrait_project where id = #{id}")
    public int delete_long_task(Integer id);

    //查询某学院横向项目申请结题
    @Select("select * from apply_transverse_project where agency = #{agency} and status = 2 and typeof = 1")
    public List<CrosswiseTask> select_unfinished_crosswise_task(Integer agency);

    //查询某学院校内课题申请结题
    @Select("select * from apply_transverse_project where agency = #{agency} and status = 2 and typeof = 2")
    public List<CrosswiseTask> select_unfinished_college_task(Integer agency);

    //查询某学院横向项目结题
    @Select("select * from apply_transverse_project where agency = #{agency} and status = 1 and typeof = 1")
    public List<CrosswiseTask> select_finished_crosswise_task(Integer agency);

    //查询某学院校内课题结题
    @Select("select * from apply_transverse_project where agency = #{agency} and status = 1 and typeof = 2")
    public List<CrosswiseTask> select_finished_college_task(Integer agency);

    //更改横向项目申请结题的审核状态
    @Update("update apply_transverse_project set status = 3 where id = #{id}")
    public int update_unfinished_width_task(Integer id);

    //删除一个横向项目
    @Delete("delete from apply_transverse_project where id = #{id}")
    public int delete_width_task(Integer id);

}
