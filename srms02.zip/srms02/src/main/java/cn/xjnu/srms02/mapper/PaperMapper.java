package cn.xjnu.srms02.mapper;

import cn.xjnu.srms02.bean.Paper;
import cn.xjnu.srms02.bean.Teacher;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Mapper
public interface PaperMapper {

    @Select("select * from paper where author_id = #{tid}")
    public List<Paper> getPaper(@PathVariable("tid") String tid);

    @Select("select * from paper where id = #{id}")
    public Paper getOnePaper(@PathVariable("id") String id);


    //@Insert("insert into paper(title_cn,title_en,first_author,author_school,authors,key,publication_date,journal,journal_id,journal_rank,paper_class,doi,author_id,desc) values(#{title_cn},#{title_en},#{first_author},#{author_school},#{authors},#{key},#{publication_date},#{journal},#{journal_id},#{journal_rank},#{paper_class},#{doi},#{author_id},#{desc})")
    @Options(useGeneratedKeys = true,keyProperty = "id")
    @Insert("insert into paper(title_cn,title_en,first_author,author_school,authors,key,publication_date,journal,journal_id,journal_rank,paper_class,doi,author_id,desc) values(#{title_cn},#{title_en},#{first_author},#{author_school},#{authors},#{key},#{publication_date},#{journal},#{journal_id},#{journal_rank},#{paper_class},#{doi},#{author_id},#{desc})")
    public int insertPaper(Paper paper);


}
