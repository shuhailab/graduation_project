package cn.xjnu.srms02.controller;

import cn.xjnu.srms02.bean.*;
import cn.xjnu.srms02.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class TestController {
    @Autowired
    TeacherMapper teacherMapper;

    @Autowired
    SecretaryMapper secretaryMapper;

    @Autowired
    ManagerMapper managerMapper;

    @Autowired
    PaperMapper paperMapper;

    @Autowired
    UserMapper userMapper;

    @GetMapping("/tech/{tid}")
    public Teacher getTeacher(@PathVariable("tid") String tid){
        return teacherMapper.selectTeacherBytid(tid);
    }

    @GetMapping(value="/paper/{id}",produces = "application/json;charset=UTF-8")
    public Paper getPaper(@PathVariable("id") String id){
        return paperMapper.getOnePaper(id);
    }

    @GetMapping("/secretary/{tid}")
    public Secretary getSecretary(@PathVariable("tid") String tid){
        return secretaryMapper.selectSecretaryByTid(tid);
    }

    @GetMapping("/manager/{tid}")
    public Manager getManager(@PathVariable("tid") String tid){

        return managerMapper.selectManagerBytid(tid);
    }

    @GetMapping("/user/{id}")
    public User getUser(@PathVariable("id") Integer id){
        User user = userMapper.getUser(id);
        System.out.println("-------------------------------------------------------------");
        System.out.println(user);
        System.out.println("这是中文这是中文这是中文这是中文");
        System.out.println("-------------------------------------------------------------------");
        return user;
    }



}
