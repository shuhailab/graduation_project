package cn.xjnu.srms02;

import cn.xjnu.srms02.bean.Paper;
import cn.xjnu.srms02.mapper.PaperMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class Srms02ApplicationTests {

    @Test
    void contextLoads() {
    }

    @Autowired
    PaperMapper paperMapper;

    @Test
    public void test(){
        List<Paper> papers = paperMapper.getPaper("201698021" );
        for(Paper paper:papers)
            System.out.println(paper);
    }

    @Test
    public void insert(){
        Paper paper = new Paper();
        paper.setTitle_cn("时间管理04");
        paper.setFirst_author("文天祥");
        paper.setAuthor_id("201698021");
        paperMapper.insertPaper(paper);
    }
}
